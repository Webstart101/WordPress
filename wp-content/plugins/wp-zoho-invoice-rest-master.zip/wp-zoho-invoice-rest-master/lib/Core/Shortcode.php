<?php
namespace NewportWaterZohoCrmInvoice\Core;

class Shortcode {
		protected $template;
		/**
		 * Add Shortcode
		 *
		 * @return Void
		 */
		public function __construct($template) {
        	$this->template = $template;
			add_shortcode(  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_link', [$this, 'create_invoice_link'] );
        	add_shortcode(  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_page', [$this, 'display_invoice_details'] );
		}

	   /**
	    * Shortcode callback to create a payment button html on page for invoice link
		* @param Array $atts 
		* @return Html
		*/
		public function create_invoice_link($atts) {

			$data = shortcode_atts( array(
            							'id' => get_query_var('invoice_id'),
            							'text' => 'View invoice',
									), $atts );
			$data['url'] = site_url(sprintf('%s/invoice/%s', WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, $data['id'] ));
			ob_start();
        	$this->template->get_template_part( 'part', 'invoice.link', $data );
        	$file = ob_get_contents();
        	ob_end_clean();
        
        	return $file;
		}

    	/**
	    * Shortcode callback to display invoice details html on page
		* @param Array $atts
		* @return Html
		*/
		public function display_invoice_details($atts) {
        	$templ = 'invoice.details';
        	$data = shortcode_atts( array(
										'id' => get_query_var('invoice_id'),
									), $atts );
        	$data = wp_newport_zoho_crm_invoice_by_id($data['id']);
        	if( is_wp_error($data) ) {
            	$templ = 'invoice.error';
            	$data = ['code' => $data->get_error_code(), 'message' => $data->get_error_message()  ];
            } else {
            	$data = $data['data'][0];
            	$data = array_merge($data, [ 
                	'currency_symbol' => $data['$currency_symbol']
                ]);
            }
        
        	ob_start();
        	$this->template->get_template_part( 'part', $templ, $data );
        	$file = ob_get_contents();
        	ob_end_clean();
        
        	return $file;
		}
}