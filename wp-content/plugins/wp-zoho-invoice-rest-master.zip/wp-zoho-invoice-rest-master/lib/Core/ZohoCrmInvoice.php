<?php

namespace NewportWaterZohoCrmInvoice\Core;

use zcrmsdk\oauth\ZohoOAuth;
use zcrmsdk\crm\crud\ZCRMModule;
use zcrmsdk\crm\crud\ZCRMRecord;
use zcrmsdk\crm\exception\ZCRMException;
use zcrmsdk\oauth\exception\ZohoOAuthException;
use zcrmsdk\crm\setup\restclient\ZCRMRestClient;
use zcrmsdk\oauth\persistence\ZohoOAuthPersistenceByFile;

/**
 * Zoho CRM Invoice class
 * @package version 1.0.0
 */
class ZohoCrmInvoice {
	
	protected $zoho;
	protected $tokens;
	
	public function __construct(array $config) {
    	try {
        	// need to integrate into wordpress as settings/options
    		ZCRMRestClient::initialize( array_merge(array(
        		"applicationLogFilePath" => __DIR__ . "/../../static/",
            	// "persistence_handler_class_name"=> ZohoOAuthPersistenceByFile::class,
            	"token_persistence_path" => __DIR__ . "/../../static/"
            	), $config) 
        	);
        	
        } catch(ZCRMException $e) {
        	throw $e;
        }
    	
    	$this->zoho = ZCRMRestClient::getInstance()->getModuleInstance("Invoices");
    }
	/**
	 * @method get_invoice_by_id
	 * Retrieves the invoice response object record of the invoice
	 * @param string $invoice_id The id of the invoice record
	 * @return array and associative array of response or error
	 */ 
	public function get_invoice_by_id( $invoice_id ) {
    	try {
        	$invoice = $this->zoho->getRecord( $invoice_id );
        	$invoice = $invoice->getResponseJSON();
        } catch(ZCRMException $e){
        	$invoice = ['error' => true, 'code' => 504,  'message' => $e->getMessage(), 'data' => ['invoice_id' => $invoice_id ] ];
        }
    
		return $invoice;
    }
	/**
	 * @method invoice_update_status
	 * Updates the status of the invoice record 
	 * @param string $invoice_id The id of the invoice record
	 * @param string $status The status of the invoice
	 * @return array and associative array of response or error
	 */ 
	public function invoice_update_status( $invoice_id, $status = 'Delivered' ) {
    	try {
        	$invoice = ZCRMRecord::getInstance( 'Invoices', $invoice_id );
        	$invoice->setFieldValue( 'Status', $status );
        	$response = $invoice->update();
        	$response = $response->getResponseJSON();
        } catch(ZCRMException $e){
        	$response = ['error' => true, 'code' => 504,  'message' => $e->getMessage(), 'data' => ['invoice_id' => $invoice_id, 'status' => $status ] ];
        }
    
		return $response;
    }
	/**
	 * @method generate_access_token
	 * Generates the tokens needed to make API requests
	 * @param string $access_code The generated access code returned from authorization
	 * @return array and associative array of tokens or error
	 */ 
	public function generate_access_token($access_code ) {
    	try {
        	$oAuthClient = ZohoOAuth::getClientInstance();
			$token = $oAuthClient->generateAccessToken($access_code);
        	$token = ['access_token' => $token->getAccessToken(), 'refresh_token' => $token->getRefreshToken() ] ;
        	
        } catch(ZohoOAuthException $e) {
            $token = ['error' => true, 'code' => 504,  'message' => $e->getMessage(), 'data' => ['access_code' => $access_code ] ];
        }
   
    	return $token;
    }
}