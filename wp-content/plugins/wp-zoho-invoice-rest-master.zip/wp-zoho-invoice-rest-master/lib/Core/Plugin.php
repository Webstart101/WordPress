<?php

namespace NewportWaterZohoCrmInvoice\Core;

use NewportWaterZohoCrmInvoice\Admin\Admin;
use NewportWaterZohoCrmInvoice\Core\Shortcode;
use NewportWaterZohoCrmInvoice\Frontend\Frontend;
use NewportWaterZohoCrmInvoice\Core\ZohoCrmInvoice;
/**
 * The core plugin class.
 */
class Plugin
{
    /**
     * The plugin's unique id.
     *
     * @var string
     */
    private $id;

    /**
     * @var Loader
     */
    private $loader;

    public function __construct($id, $version)
    {
        $this->id = $id;

        $this->loader = new Loader();
        $this->loader->add_action('plugins_loaded', $this, 'load_plugin_textdomain');
    	$this->loader->add_filter( 'rewrite_rules_array', $this, 'insert_rewrite_rules' );
		$this->loader->add_filter( 'query_vars', $this, 'insert_query_vars' );
    	$this->loader->add_action(  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_create_link', $this, 'create_invoice_link', 10, 1 );
    	$this->loader->add_action(  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_update_status', $this, 'update_invoice_status' , 10, 1);
    
        $assets = new Assets($id, $version, $this->loader, is_admin());
        $templating = new Templating();

        if (is_admin()) {
            new Admin($this->loader, $assets, $templating);
        	
        } else {
            new Frontend($this->loader, $assets, $templating);
        }
    	
    	
    
    	new Shortcode($templating);
    
    }
	/**
	 * @method update_invoice_status
	 * Updates the status of the invoice record 
	 * @param string $invoice_id The id of the invoice record
	 * @param string $status The status of the invoice
	 * @return @void
	 */  
	public function update_invoice_status($invoice_id, $status = 'Approved') 
    {
    	$result = wp_newport_zoho_crm_invoice_update_status($invoice_id, $status);
    	if(is_wp_error($result)) 
        {
        	error_log("zoho update invoice status" . print_r($result, true ));
        }
    }
	/**
	 * @method create_invoice_link
	 * Prints an invoice details display link from url
	 * @param string $invoice_id The id of the invoice record
	 * @return @void
	 */  
	public function create_invoice_link($invoice_id) {
    	wp_newport_zoho_crm_invoice_display_invoice_link($invoice_id, 'Go Back');
    }
	/**
	 * @method insert_rewrite_rules
	 * Adds rewrite rule for invoice details link
	 * @param array $rules existing rules
	 * @return array Returns prepended rule for the invoice link
	 */  
	public function insert_rewrite_rules($rules) 
    {
    	$newrules = array();
    	$newrules[ WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '/invoice/([0-9]{1,})/?'] = 'index.php?pagename='.  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '&invoice_id=$matches[1]';
    	return $newrules + $rules;
    }
	/**
	 * @method insert_query_vars
	 * Adds invoice_id variable to allowed list of params
	 * @param array $vars existing variables
	 * @return array Returns appended variables
	 */
	public function insert_query_vars($vars)
    {
    	array_push( $vars, 'invoice_id' );
    	return $vars;
    }

    /**
     * Run the plugin.
     */
    public function run()
    {
        $this->loader->register_hooks();
    }

    /**
     * Load internationalization files.
     */
    public function load_plugin_textdomain()
    {
        load_plugin_textdomain(
            $this->id,
            $deprecated = false,
            __DIR__.'/../../languages/'
        );
    }
}
