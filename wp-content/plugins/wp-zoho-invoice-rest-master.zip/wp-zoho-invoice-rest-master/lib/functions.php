<?php 
use NewportWaterZohoCrmInvoice\Core\ZohoCrmInvoice;

defined('WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN')  or define('WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN', 'wp-newport-zoho-crm-invoice');
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_PLUGIN_PATH') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_PLUGIN_PATH', plugin_dir_path(__DIR__));
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_CLIENT_ID') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_CLIENT_ID', get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['client_id'] ?? null );
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_CLIENT_SECRET') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_CLIENT_SECRET', get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['client_secret'] ?? null );
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_REDIRECT_URI') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_REDIRECT_URI', admin_url('options-general.php?page=' . WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings') );
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_SANDBOX') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_SANDBOX', get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['sandbox'] ?? false );
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_DOMAIN_SUFFIX') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_DOMAIN_SUFFIX', get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['domain'] ?? null  );
defined('WP_NEWPORT_ZOHO_CRM_INVOICE_USER_EMAIL') or define('WP_NEWPORT_ZOHO_CRM_INVOICE_USER_EMAIL', get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['user_email'] ?? null  );

if(!function_exists('wp_newport_zoho_crm_invoice_by_id')) {
	/**
	 * @method wp_newport_zoho_crm_invoice_by_id
	 * Gets the invoice response object record of the invoice
	 * @param string $invoice_id The id of the invoice record
	 * @return WP_Error|array and associative array of response or wp_error object
	 */ 
	function wp_newport_zoho_crm_invoice_by_id($invoice_id) {
    	if(is_null($invoice_id)) return [];
    	
    	$zoho = wp_newport_zoho_crm_invoice();
    	$response = $zoho->get_invoice_by_id( $invoice_id );
    	return wp_newport_zoho_crm_invoice_is_error($response);
    }
}

if(!function_exists('wp_newport_zoho_crm_invoice_update_status')) {
	/**
	 * @method wp_newport_zoho_crm_invoice_update_status
	 * Updates the invoice record with the appropriate status
	 * @param string $invoice_id The id of the invoice record
	 * @param string $status the status of the invoice record
	 * @return WP_Error|array and associative array of response or wp_error object
	 */ 
	function wp_newport_zoho_crm_invoice_update_status($invoice_id, $status = 'Delivered') {
    	if(is_null($invoice_id)) return [];
    
    	$zoho = wp_newport_zoho_crm_invoice();
    	$response = $zoho->invoice_update_status( $invoice_id, $status );
    	return wp_newport_zoho_crm_invoice_is_error($response);
    }
}

if(!function_exists('wp_newport_zoho_crm_invoice_generate_token')) {
	/**
	 * @method wp_newport_zoho_crm_invoice_generate_access_token
	 * Generates the tokens from the given access code
	 * @param string $code The returned access code
	 * @param string $grant_type the type of access 
	 * @return WP_Error|array and associative array of response or wp_error object
	 */ 
	function wp_newport_zoho_crm_invoice_generate_access_token($code, $grant_type = 'authorization_code') {
    	if(is_null($code)) return [];
    
    	$zoho = wp_newport_zoho_crm_invoice();
    	$response = $zoho->generate_access_token( $code, $grant_type );
    	return wp_newport_zoho_crm_invoice_is_error($response);
    }
}

if(!function_exists('wp_newport_zoho_crm_invoice')) {
	/**
	 * @method wp_newport_zoho_crm_invoice
	 * Returns a ZohoCrmInvoice object
	 * @param array $config An array of overriding configuration options
	 * @return ZohoCrmInvoice returns a ZohoCrmInvoice object
	 */ 
	function wp_newport_zoho_crm_invoice (array $config = [])
    {	
    	return new ZohoCrmInvoice(array_merge([
        		'domainSuffix' => WP_NEWPORT_ZOHO_CRM_INVOICE_SANDBOX ? null : WP_NEWPORT_ZOHO_CRM_INVOICE_DOMAIN_SUFFIX,
        		'sandbox' => WP_NEWPORT_ZOHO_CRM_INVOICE_SANDBOX,
        		'apiBaseUrl' => (defined('WP_NEWPORT_ZOHO_CRM_INVOICE_API_BASE_URL') ? WP_NEWPORT_ZOHO_CRM_INVOICE_API_BASE_URL : null)  ?? (WP_NEWPORT_ZOHO_CRM_INVOICE_SANDBOX ? 'sandbox.zohoapis.' . ( (defined('WP_NEWPORT_ZOHO_CRM_INVOICE_DOMAIN_SUFFIX')? WP_NEWPORT_ZOHO_CRM_INVOICE_DOMAIN_SUFFIX : null) ?? 'com') : null )
        	], $config, [
        	'client_id' => WP_NEWPORT_ZOHO_CRM_INVOICE_CLIENT_ID,
        	'client_secret' => WP_NEWPORT_ZOHO_CRM_INVOICE_CLIENT_SECRET,
        	'redirect_uri' => WP_NEWPORT_ZOHO_CRM_INVOICE_REDIRECT_URI,
        	'currentUserEmail' => WP_NEWPORT_ZOHO_CRM_INVOICE_USER_EMAIL
        ]));
    }
}

if(!function_exists('wp_newport_zoho_crm_invoice_is_error')) {
	/**
	 * @method wp_newport_zoho_crm_invoice_is_error
	 * Checks if the response is an and returns a WP_Error object
	 * @param mixed $response The response to validate
	 * @return WP_Error|mixed either the original response or WP_Error
	 */ 
	function wp_newport_zoho_crm_invoice_is_error ($response)
    {
    	if(is_array($response) && array_key_exists('error', $response)) 
        {
        	extract($response);
        	$response =  new \WP_Error($code, $message, $data);
        }
    
    	return $response;
    }
}

if(!function_exists('wp_newport_zoho_crm_invoice_display_invoice_link')) {
	/**
	 * @method  wp_newport_zoho_crm_invoice_display_invoice_link
	 * Displays a link to the invoice by id using shortcode
	 * @param string $invoice_id the id of the invoice record
	 * @param string $text the link display text
	 * @return @void
	 */ 
	function wp_newport_zoho_crm_invoice_display_invoice_link($invoice_id, $text = 'View Link') {
    	print do_shortcode(sprintf("[".  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . "_link id='%s' text='%s']", $invoice_id, $text ));
    }
}
