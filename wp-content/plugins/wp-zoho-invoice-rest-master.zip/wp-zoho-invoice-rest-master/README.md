# Newport Water WP Zoho CRM Invoice REST Plugin

Custom plugin for interactive with Zoho CRM invoice modules for Newport Water. The plugin creates a front end landing page at **wp-newport-zoho-crm-invoice/invoice/*invoice_id*** Where *invoice_id* is the id of the invoice record you wish to query and display. 

## Installation

1. Install directly into the plugins folder 
2. Activate the plugin
3. Enter the developer information obtained from the [Zoho API Client](https://www.zoho.com/crm/developer/docs/api/v2/register-client.html) into the plugins settings page.
4. Authorize the plugin when prompted to.
5. Click save to save the updated settings.
6. Implement hooks in theme functions.

## Notes

The following hooks would need to be implemented
- `do_action('wp-newport-zoho-crm-invoice_after_invoice_details', array $payment_details)`- handle this event after invoice details are displayed
- `do_action('wp-newport-zoho-crm-invoice_update_status', string $invoice_id)` - trigger this event to update the status of invoice if payment successful
- `do_action('wp-newport-zoho-crm-invoice_create_link', string $invoice_id)`- trigger this event to create an invoice display link button

### `/lib` Files

`/lib/functions.php` :: Helper functions and constants

`/lib/Core/Assets.php` :: `Assets` handles the plugin assets

`/lib/Core/Templating.php` :: `Templating` handles the plugin template files and loading

`/lib/Core/Loader.php` :: `Loader` handles the plugin actions and filters registration

`/lib/Core/Shortcode.php` :: `Shortcode` handles the plugin's short code creation

`/lib/Core/Plugin.php` :: `Plugin` initializes the plugin

`/lib/Core/ZohoCrmInvoice.php` :: `ZohoCrmInvoice` custom class to handle Zoho Crm Invoice actions/ methods for Newport Water

### `/src` Files

`/src/Admin/Admin.php` :: `Admin` handles admin initializing

`/src/Admin/Settings.php` :: `Settings` handles admin settings page

`/src/Command/Command.php` :: `Command` handles plugin CLI, cron job tasks

`/src/Frontend/Frontend.php` :: `Frontend`intializes plugin's front end tasks

`/src/Lifecycle.php` :: `Lifecycle` handles the plugin's install uninstall

### `/templates` Template Files

`/templates/part-invoice.details.php`:: Template for invoice details display page
`/templates/part-invoice.error.php`:: Template for error messages
`/templates/part-invoice.link.php`:: Template for invoice link button

## Ack

- [WP Plugin Boilerplate](https://github.com/psrpinto/regularjack.github.io)
