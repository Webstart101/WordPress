<?php

//ini_set('display_errors',1);
//error_reporting(E_ALL);

namespace NewportWaterZohoCrmInvoice\Frontend;

use NewportWaterZohoCrmInvoice\Rest\ZohoCrmInvoiceRest;
/**
 * Frontend-facing functionality.
 */
class Frontend
{
    public function __construct($loader, $assets, $templating)
    {
        $assets->add_style('frontend/css/frontend.css');
        $assets->add_script('frontend/js/frontend.js');
    }
}
