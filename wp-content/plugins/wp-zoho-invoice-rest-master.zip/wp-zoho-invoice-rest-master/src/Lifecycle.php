<?php

namespace NewportWaterZohoCrmInvoice;

require_once __DIR__.'/../lib/functions.php';

/**
 * Code to run during the plugin's activation, deactivation or uninstallation.
 */
class Lifecycle
{
    /**
     * This method is automatically called on plugin activation.
     */
    public static function activate()
    {
    	self::install();
    }

    /**
     * This method is automatically called on plugin deactivation.
     */
    public static function deactivate()
    {
    }

    /**
     * This method is automatically called on plugin uninstallation.
     */
    public static function uninstall()
    {
    
    		if(($page = get_page_by_path( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, OBJECT, 'page' )) )
            	wp_delete_post( $page->ID, true);
    }

	public static function install()
    {
    	if(is_null($page = get_page_by_path( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, OBJECT, 'page' )) )
        wp_insert_post([
            	'post_title'=>'Newport Water Customer Payment Details', 
  				'post_type'=> 'page', 
        		'post_status' => 'publish',
  				'post_content'=> '<!-- wp:shortcode -->[' . WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_page]<!-- /wp:shortcode -->',
            	'post_name' => WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN
            ]);
    }
}
