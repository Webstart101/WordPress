<?php

namespace NewportWaterZohoCrmInvoice\Admin;

use NewportWaterZohoCrmInvoice\Admin\Settings;

/**
 * Admin-specific functionality.
 */
class Admin
{

	private $settings;

    public function __construct($loader, $assets, $templating)
    {
        $assets->add_style('admin/css/admin.css');
        $assets->add_script('admin/js/admin.js');
    	$loader->add_action('add_option_wp-newport-zoho-crm-invoice_settings', $this, 'authorize_zoho_options', 10 ,2 );
    	//$loader->add_action('update_option_wp-newport-zoho-crm-invoice_settings', $this, 'update_zoho_options', 10 ,3 );
    
    	$this->settings = new Settings($loader, $templating);
    }
	/**
	 * @method authorize_zoho_options
	 * Redirects user to authorize plugin
	 * @param string $option the name of the option
	 * @param mixed $value the value of the option
	 * @return @void
	 */ 
	public function authorize_zoho_options($option, $value) {
    	if(empty($value['refresh_token']))
    	wp_redirect(sprintf("https://accounts.zoho.com/oauth/v2/auth?scope=ZohoCRM.modules.invoices.READ,ZohoCRM.modules.invoices.UPDATE,AAAserver.profile.Read&client_id=%s&response_type=code&access_type=offline&redirect_uri=%s", 
                            $value[ 'client_id'],
                            admin_url('options-general.php?page=wp-newport-zoho-crm-invoice_settings')
                           ));
    	exit;
    }
}
