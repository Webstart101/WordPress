<?php

namespace NewportWaterZohoCrmInvoice\Admin;

class Settings
{
    private $templating;

    public function __construct($loader, $templating)
    {
        $this->templating = $templating;
    	
    	$loader->add_action( 'admin_init',  $this, 'register_settings' );
		$loader->add_action( 'admin_menu' , $this, 'admin_menu' );
        $loader->add_filter( 'plugin_action_links_' . basename(WP_NEWPORT_ZOHO_CRM_INVOICE_PLUGIN_PATH) . '/plugin.php' , $this, 'register_settings_link' );
    }

	public function register_settings_link( $links ) {
		// Build and escape the URL.
		$url = esc_url( add_query_arg(
			'page',
			 WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings',
			 get_admin_url() . 'options-general.php'
		) );
		// Create the link.
		$settings_link = "<a href='$url'>" . __( 'Settings' ) . '</a>';
		// Adds the link to the end of the array.
		array_push(
			$links,
			$settings_link
		);
	
    	return $links;
	}

    public function admin_menu()
    {
        add_options_page(
            null,// __('WP Newport Zoho CRM Invoice REST Plugin', WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN ),
            null, //__('WP Newport Zoho CRM Invoice REST Plugin', WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN ),
            'manage_options',
            WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings',
            array($this, 'settings_page')
        );
    }

    public function settings_page()
    {
    	?>
        <div class="wrap">
				<h1>WP Newport Zoho CRM Invoice Plugin</h1>
				<br class="clear">
        		<p>Set the initial configuration settings for the plugin. You will be asked to authorize and give permission to the plugin before saving.</p>
				<?php settings_errors();
					/**
					 * Following is the settings form
					 */ ?>
					<form method="post" action="options.php">
						<?php
    					settings_fields( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings');
						do_settings_sections( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings');
						submit_button( __( isset($_GET['code']) ? 'Save Settings' : ( WP_NEWPORT_ZOHO_CRM_INVOICE_DOMAIN_SUFFIX ? 'Update Settings' : 'Authorize Plugin'), WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN  ), 'primary', 'id' ); ?>
					</form>
			</div>
		<?php
    }
	/**
	 * @method get_fresh_token
	 * Gets the refresh token returned from the token genration request for the plugin using the submitted access_code
	 * @param string $code An access_code token sent back from authorization
	 * @return string|null the generated access token or null
	 */
	private function get_refresh_token($code) 
    {
    	if(is_wp_error( $token = wp_newport_zoho_crm_invoice_generate_access_token($code))) $token = null;
           
        return $token['refresh_token'] ?? null ;
    }
	/*#
	 * @method register_setttings
	 * Sets up the necessary variables needed to communicate with the Zoho CRM invoice module.
	 */
	function register_settings() {
    	register_setting( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', array(
            'type' => 'array', 
        	'description' => 'Set the initial configuration settings for the plugin. You will be asked to authorize the plugin before saving.',
            'sanitize_callback' => [$this, 'sanitize_fields'],
            'default' => NULL,
            ) );
    	add_settings_section( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                             'API Settings', null , 
                             WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_client_id', 
                           	'Client ID', [ $this, 'setting_client_id_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_client_secret', 
                           	'Client Secret', [ $this, 'setting_client_secret_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_user_email', 
                           	'User Email', [ $this, 'setting_user_email_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_sandbox', 
                           	'Use Sandbox', [ $this, 'setting_sandbox_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_domain', 
                           	'User Domain', [ $this, 'setting_domain_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_server', 
                           	'User Sever', [ $this, 'setting_server_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
    	
    	add_settings_field( WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_refresh_token', 
                           	'Refresh Token', [ $this, 'setting_refresh_token_field' ], 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings', 
                           	WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings' );
	}
	/**
	 * User account zoho url
	 * @return Returns input html
	 */
	function setting_server_field()
    {
    	printf('<input type="text" class="medium-text" readonly name="%s_settings[server]" id="%s_server" value="%s" required /><p class="description" id="tagline-description">The server location for account user.</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['server'] ?? $_GET['accounts-server'] ?? null
                 );
    }
	/**
	 * User account email
	 * @return Returns input html
	 */
	function setting_user_email_field()
    {
    	printf('<input type="text" class="medium-text" name="%s_settings[user_email]" id="%s_user_email" value="%s" required place_holder="%s" /><p class="description" id="tagline-description">Zoho account user email address.</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['user_email'] ?? null,
               		__( 'Enter valid email address',  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN )
                 );
    }
	/**
	 * Enables/ Disables sandbox mode for plugin
	 * @return Returns input html
	 */
	function setting_sandbox_field()
    {
    	printf('<input type="checkbox" class="medium-text" name="%s_settings[sandbox]" id="%s_sandbox" value="sandbox" %s /><p class="description" id="tagline-description">Enable to test plugin in sandbox mode.</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   isset(get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['sandbox']) ? 'checked' : ''
                 );
    }
	/**
	 * User account domain zone
	 * @return Returns input html
	 */
	function setting_domain_field()
    {
    	printf('<input type="text" class="medium-text" readonly name="%s_settings[domain]" id="%s_domain" value="%s" required /><p class="description" id="tagline-description">The domain location for account user.</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['domain'] ?? $_GET['location'] ?? null
                 );
    }
	/**
	 * Developer client id
	 * @return Returns input html
	 */
	function setting_client_id_field()
    {
    	printf('<input type="text" class="medium-text" name="%s_settings[client_id]" id="%s_client_id" value="%s" placeholder="%s" required /><p class="description" id="tagline-description">The zoho account client ID.</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['client_id'] ?? null,
                   __( 'Enter client id',  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN )
                 );
    }
	/**
	 * Developer client secret
	 * @return Returns input html
	 */
	function setting_client_secret_field()
    {
    	printf('<input type="text" class="medium-text" name="%s_settings[client_secret]" id="%s_client_secret" value="%s" placeholder="%s" required /><p class="description" id="tagline-description">The zoho account client secret.</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['client_secret'] ?? null,
                   __( 'Enter client secret',  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN )
                 );
    }
	/**
	 * The generated refresh token
	 * @return Returns input html
	 */
	function setting_refresh_token_field()
    {
    	printf('<input type="text" class="medium-text" name="%s_settings[refresh_token]" readonly id="%s_refresh_token" value="%s" /><p class="description" id="tagline-description">Refresh token from zoho</p>',
                  WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN, 
                   get_option(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_settings')['refresh_token'] ?? (isset($_GET['code']) ? $this->get_refresh_token($_GET['code']) : null),
               	
                 );
    }

	function sanitize_fields ($input) {
    	$input = array_filter($input);
    	$input = array_map('sanitize_text_field', $input);
    	return $input;
    }
}
