<?php do_action(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_before_invoice_details', compact( 'currency_symbol', 'id', 'Grand_Total') ) ?>
<h3>Invoice # <?php print $Invoice_Number; ?></h3>
<p>Payment Information:</p>
<table>
	<tbody>
    	<tr><th colspan="2">Billing Information</th></tr>
    	<tr><th>Name:</th><td><?php print $Contact_Name['name'] ?></td></tr>
    	<tr><th>Billing Address:</th><td><?php print $Billing_Street ?> <?php print $Billing_City ?></td></tr>
    	<tr><th>Grand_Total:</th><td>$<?php print number_format($Grand_Total, 2) ?> <?php print $currency_symbol ?></td></tr>
	</tbody>
</table>
<?php do_action(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_after_invoice_details', compact( 'currency_symbol', 'id', 'Grand_Total') ) ?>