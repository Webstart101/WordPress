<?php do_action(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_before_invoice_error'); ?>
<h3>Error</h3>
<p><?php print $message ?></p>
<?php do_action(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_after_invoice_error'); ?>