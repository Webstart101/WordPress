<?php do_action(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_before_invoice_link', $id ) ?>
<p class="wp_newport_zoho_crm_invoice invoice_link"><a class="wp_newport_zoho_crm_invoice invoice_button btn btn-primary button button-default" href="<?php print $url ?>"><?php print $text ?></a></p>
<?php do_action(WP_NEWPORT_ZOHO_CRM_INVOICE_TEXT_DOMAIN . '_after_invoice_link', $id ) ?>
