=== Newport Water WP Zoho CRM Invoice REST Plugin ===
Contributors: Kendall Arneaud
Tags: zoho, invoice, crm
Requires at least: 5.2
Tested up to: 5.5
Stable tag: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom plugin to get/ display Zoho CRM invoice module records by invoice id and update status using invoice id. 

== Description ==

Cusomt plugin for Newport Water to retrieve invoice information by passed invoice id via Zoho CRM REST API. 

== Installation ==

1. Install directly into the plugins folder 
2. Activate the plugin
3. Enter the developer information obtained from the [Zoho API Client](https://www.zoho.com/crm/developer/docs/api/v2/register-client.html) into the plugins settings page.
4. Authorize the plugin when prompted to.
5. Click save to save the updated settings.
6. Implement hooks in theme functions.

== Features ==

1. Shortcode implementations
2. Custom actions
3. Helper functions
4. Custom page for easy editing via page section
5. Template files to easy customize. Just copy over to theme folders in a sub directory called wp-newport-zoho-crm-invoice
6. Overriding constants

== Notes ==

The following hooks would need to be implemented
* `do_action('wp-newport-zoho-crm-invoice_after_invoice_details', array $payment_details)`- handle this event after invoice details are displayed
* `do_action('wp-newport-zoho-crm-invoice_update_status', string $invoice_id)` - trigger this event to update the status of invoice if payment successful
* `do_action('wp-newport-zoho-crm-invoice_create_link', string $invoice_id)`- trigger this event to create an invoice display link button


== Changelog ==
